"""Diagnostic replay: same prompts/sampling, streaming only for early failure detection."""
import argparse
import asyncio
import json
import pathlib
import re
import time

import aiohttp

ROOT = pathlib.Path('/workspace')
MODEL = '/mnt/weight/Qwen3-235B-A22B-w8a8-QuaRot'

def defect(text):
    if re.search(r'([^\s\w])\1{127,}', text):
        return 'repeated_punctuation'
    if '\ufffd' in text:
        return 'replacement_character'
    if text.count('</think>') >= 3:
        return 'repeated_think_close'
    return None

async def main(args):
    source = next((ROOT/'run03-quarot-20260920/client/outputs').rglob('*.jsonl'))
    rows = [json.loads(line) for line in source.read_text().splitlines()]
    bad = sorted((r for r in rows if defect(r['prediction'])), key=lambda r:r['id'])[:args.cases]
    if args.archive:
        found = [{'id':r['id'],'defect':defect(r['prediction'])} for r in bad]
        print(json.dumps({'archive_red':bool(found),'bad_cases':found}), flush=True)
        return
    out = ROOT/'quarot-debug'/args.label
    out.mkdir(parents=True,exist_ok=True)
    semaphore = asyncio.Semaphore(args.concurrency)
    stop = asyncio.Event()
    async with aiohttp.ClientSession(trust_env=False,timeout=aiohttp.ClientTimeout(total=2400)) as session:
        async def replay(row, repeat):
            async with semaphore:
                if stop.is_set(): return
                messages=[{'role':{'HUMAN':'user','BOT':'assistant','SYSTEM':'system'}.get(p['role'],p['role']),'content':p['prompt']} for p in row['origin_prompt']]
                request={'model':MODEL,'messages':messages,'temperature':0.6,'top_p':0.95,'max_tokens':32768,'ignore_eos':False,'chat_template_kwargs':{'thinking':True},'stream':True}
                result={'id':row['id'],'repeat':repeat,'request':request,'text':'','defect':None,'started':time.time()}
                try:
                    async with session.post('http://178.27.4.197:1999/v1/chat/completions',json=request) as response:
                        response.raise_for_status()
                        async for raw in response.content:
                            line=raw.decode('utf-8').strip()
                            if not line.startswith('data:') or line[5:].strip()=='[DONE]':continue
                            data=json.loads(line[5:]);choices=data.get('choices',[])
                            if not choices:continue
                            delta=choices[0].get('delta',{})
                            result['text']+=delta.get('reasoning_content') or delta.get('reasoning') or delta.get('content') or ''
                            result['finish_reason']=choices[0].get('finish_reason')
                            result['defect']=defect(result['text'])
                            if result['defect']:
                                stop.set();break
                except Exception as exc:
                    result['error']=repr(exc)
                result['seconds']=time.time()-result['started']
                (out/f"sample-{row['id']}-{repeat}.json").write_text(json.dumps(result,ensure_ascii=False,indent=2))
                print(json.dumps({k:v for k,v in result.items() if k not in ['request','text']}),flush=True)
        tasks=[asyncio.create_task(replay(row,repeat)) for repeat in range(args.repeats) for row in bad]
        for done in asyncio.as_completed(tasks):
            await done
            if stop.is_set():
                for task in tasks:
                    if not task.done(): task.cancel()
                await asyncio.gather(*tasks,return_exceptions=True)
                break
    print('REPRO_RED' if stop.is_set() else 'REPRO_FINISHED',flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--label',default='baseline-v023')
    parser.add_argument('--cases',type=int,default=8)
    parser.add_argument('--concurrency',type=int,default=8)
    parser.add_argument('--repeats',type=int,default=1)
    parser.add_argument('--archive',action='store_true')
    asyncio.run(main(parser.parse_args()))
