import json
from pathlib import Path
from ais_bench.benchmark.utils.postprocess.model_postprocessors import extract_non_reasoning_content
from ais_bench.benchmark.datasets.gsm8k import gsm8k_postprocess, gsm8k_dataset_postprocess, Gsm8kEvaluator

root=Path('/workspace/run05-noeplb-quarot-20260920')
baseline_path=next(Path('/workspace/run04-v023-quarot-20260920/client/outputs').rglob('*.jsonl'))
baseline={r['id']:r for r in map(json.loads,baseline_path.read_text().splitlines())}
current_path=next((root/'client/outputs').rglob('results/vllm-api-general-chat/gsm8k.json'))
current=json.loads(current_path.read_text())['details']
evaluator=Gsm8kEvaluator()
old_correct={i:evaluator.is_equal(gsm8k_postprocess(extract_non_reasoning_content(r['prediction'])),gsm8k_dataset_postprocess(r['gold'])) for i,r in baseline.items()}
new_correct={int(i):r['correct'][0] for i,r in current.items() if str(i).isdigit()}
common=sorted(set(old_correct)&set(new_correct))
result={'common_samples':len(common),'baseline_correct':sum(old_correct[i] for i in common),'noeplb_correct':sum(new_correct[i] for i in common),
        'baseline_only_correct':[i for i in common if old_correct[i] and not new_correct[i]],
        'noeplb_only_correct':[i for i in common if new_correct[i] and not old_correct[i]],
        'missing_from_baseline':sorted(set(new_correct)-set(old_correct))}
for prefix in ['baseline','noeplb']:
 result[prefix+'_accuracy']=100*result[prefix+'_correct']/len(common)
(root/'paired-comparison.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
