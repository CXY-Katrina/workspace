import collections
import json
import pathlib
import re
import sys
from remote import connect

root=pathlib.Path(sys.argv[1])
client=connect('192.168.13.197')
sftp=client.open_sftp()
sftp.get('/mnt/share/qwen235-acc-20260919/run05-noeplb-quarot-20260920/paired-comparison.json',str(root/'paired-comparison.json'),max_concurrent_prefetch_requests=4)
sftp.close();client.close()
result=json.loads(next((root/'client/outputs').rglob('results/vllm-api-general-chat/gsm8k.json')).read_text(encoding='utf-8'))
details={int(k):v for k,v in result['details'].items() if str(k).isdigit()}
predictions={r['id']:r for r in map(json.loads,next((root/'client/outputs').rglob('predictions/vllm-api-general-chat/gsm8k.jsonl')).read_text(encoding='utf-8').splitlines())}
baseline={r['id']:r for r in map(json.loads,(root/'baseline-predictions.jsonl').read_text(encoding='utf-8').splitlines())}
assert all(predictions[i]['origin_prompt']==r['origin_prompt'] and predictions[i]['gold']==r['gold'] for i,r in baseline.items())
metrics=collections.Counter()
for path in (root/'metrics').glob('node-[12]-*.prom'):
    for line in path.read_text(encoding='utf-8').splitlines():
        if line.startswith('vllm:request_success_total{'):
            metrics[re.search(r'finished_reason="([^"]+)"',line)[1]]+=int(float(line.rsplit(' ',1)[1]))
flags=json.loads((root/'audit/flagged-samples.json').read_text(encoding='utf-8'))
print('flag overview',json.dumps([{'id':r['index'],'flags':r['flags']} for r in flags]))
abnormal=[]
for index in [1052,1078]:
    row=details[index]
    text=row['origin_prediction']
    old=baseline[index]['prediction']
    evidence={'id':index,'current_chars':len(text),'baseline_chars':len(old),'current_correct':row['correct'][0],
              'prediction':row['predictions'][0],'reference':row['references'][0],
              'hmm_count':text.count('Hmm.'),'equation_loop_count':text.count('90 + 100 = 190? No. Wait,'),
              'baseline_thinking_closed':'</think>' in old,'baseline_tail':old[-1200:]}
    abnormal.append(evidence)
    (root/'audit'/f'abnormal-{index}.txt').write_text(text,encoding='utf-8')
    (root/'audit'/f'baseline-{index}.txt').write_text(old,encoding='utf-8')
old_bad=[12,93,98,100,106,119,120,125,161,182,184,187,197,205,209,212,214,229,236,241,242,245,249,252,253,255,256,257,259,260,261,264,265,266,267,268,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293]
review={'samples':len(predictions),'all_requests_success':all(r['success'] for r in predictions.values()),'decode_finish_reasons':dict(metrics),
        'prompt_and_gold_identical_on_common_1314':True,'abnormal_samples':abnormal,
        'benign_phrase_flags':[int(r['index']) for r in flags if int(r['index']) not in [1052,1078]],
        'previous_bad_cases':{'samples':len(old_bad),'correct':sum(details[i]['correct'][0] for i in old_bad),
           'long_character_runs':sum(bool(re.search(r'([^\s])\1{49,}',details[i]['origin_prediction'])) for i in old_bad)}}
(root/'audit/review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(review,ensure_ascii=True))
