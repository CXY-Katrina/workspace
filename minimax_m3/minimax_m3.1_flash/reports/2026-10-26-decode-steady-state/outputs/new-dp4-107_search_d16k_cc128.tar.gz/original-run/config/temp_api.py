from ais_bench.benchmark.models import VLLMCustomAPIChatStream

models = [
    dict(
        attr="service",
        type=VLLMCustomAPIChatStream,
        abbr='vllm-api-stream-chat',
        path="/work/decode-dp4-tp4-ep16-20261026/tokenizer",
        model="minimax-m3.1-flash",
        api_key="",
        request_rate=0,
        retry=2,
        host_ip="197.13.50.1",
        host_port=8009,
        url="",
        max_out_len=1024,
        batch_size=128,
        generation_kwargs=dict(
            temperature=0,
            ignore_eos=True,
        )
    )
]
