cli_args=dict(
    {'agent': None,
    'agent_api_key': None,
    'agent_dataset_path': None,
    'agent_deps': None,
    'agent_env': None,
    'agent_import_path': None,
    'agent_kwarg': None,
    'api_base': None,
    'api_key': None,
    'batch_size': None,
    'cfg_time_str': '20261026_111453',
    'config': None,
    'config_dir': 'configs',
    'custom_dataset_data_type': None,
    'custom_dataset_infer_method': None,
    'custom_dataset_meta_path': None,
    'custom_dataset_path': None,
    'dataset': None,
    'datasets': [
        'gsm8k_gen_0_shot_cot_str_perf',
        ],
    'debug': True,
    'delete/__no_delete': None,
    'dir_time_str': '20261026_111453',
    'disable_verification': None,
    'dry_run': False,
    'dump_eval_details': False,
    'dump_extract_rate': False,
    'env_file': None,
    'environment': None,
    'exclude_task_name': None,
    'extra_docker_compose': None,
    'force_build/__no_force_build': None,
    'generation_kwargs': None,
    'host_ip': None,
    'host_network': None,
    'host_port': None,
    'include_task_name': None,
    'max_num_workers': 1,
    'max_out_len': None,
    'max_retries': None,
    'max_workers_per_gpu': 1,
    'merge_ds': False,
    'mode': 'perf',
    'model': None,
    'model_name': None,
    'models': [
        'vllm_api_chat_temp',
        ],
    'monitor_port': 0,
    'n_attempts': None,
    'n_concurrent': None,
    'n_tasks': None,
    'num_prompts': None,
    'num_warmups': 0,
    'path': None,
    'pressure': False,
    'pressure_time': 15,
    'purge_exception_cases': False,
    'quiet': None,
    'request_rate': None,
    'response_anomaly': False,
    'response_anomaly_payload_retention': None,
    'retry': None,
    'reuse': None,
    'search': False,
    'spec_decode': False,
    'summarizer': 'default_perf',
    'timeout_multiplier': None,
    'trust_remote_code': None,
    'url': None,
    'work_dir': '/work/decode-dp4-tp4-ep16-20261026/runs/111_refine_d16k_cc91/aisbench/outputs',
    'yes': None})
datasets=[
    dict(abbr='gsm8k',
        eval_cfg=dict(
            dataset_postprocessor=dict(
                type='ais_bench.benchmark.datasets.gsm8k.gsm8k_dataset_postprocess'),
            evaluator=dict(
                type='ais_bench.benchmark.datasets.gsm8k.Gsm8kEvaluator'),
            pred_postprocessor=dict(
                type='ais_bench.benchmark.datasets.gsm8k.gsm8k_postprocess'),
            pred_role='BOT'),
        infer_cfg=dict(
            inferencer=dict(
                type='ais_bench.benchmark.openicl.icl_inferencer.icl_gen_inferencer.GenInferencer'),
            prompt_template=dict(
                template='{question}',
                type='ais_bench.benchmark.openicl.icl_prompt_template.icl_prompt_template.PromptTemplate'),
            retriever=dict(
                prompt_template=dict(
                    template='{question}',
                    type='ais_bench.benchmark.openicl.icl_prompt_template.icl_prompt_template.PromptTemplate'),
                type='ais_bench.benchmark.openicl.icl_retriever.icl_zero_retriever.ZeroRetriever')),
        path='ais_bench/datasets/gsm8k',
        reader_cfg=dict(
            input_columns=[
                'question',
                ],
            output_column='answer'),
        type='ais_bench.benchmark.datasets.gsm8k.GSM8KDataset'),
    ]
infer=dict(
    partitioner=dict(
        out_dir='/work/decode-dp4-tp4-ep16-20261026/runs/111_refine_d16k_cc91/aisbench/outputs/20261026_111453/predictions/',
        type='ais_bench.benchmark.partitioners.naive.NaivePartitioner'),
    runner=dict(
        debug=True,
        max_num_workers=1,
        max_workers_per_gpu=1,
        task=dict(
            type='ais_bench.benchmark.tasks.openicl_api_infer.OpenICLApiInferTask'),
        type='ais_bench.benchmark.runners.local.LocalRunner'))
models=[
    dict(abbr='vllm-api-stream-chat',
        api_key='',
        attr='service',
        batch_size=91,
        generation_kwargs=dict(
            ignore_eos=True,
            temperature=0),
        host_ip='197.13.50.1',
        host_port=8009,
        max_out_len=1024,
        model='minimax-m3.1-flash',
        path='/work/decode-dp4-tp4-ep16-20261026/tokenizer',
        request_rate=0,
        retry=2,
        type='ais_bench.benchmark.models.api_models.vllm_custom_api_chat.VLLMCustomAPIChatStream',
        url=''),
    ]
response_anomaly=dict(
    enabled=False,
    msprobe_config_path=None,
    payload_retention='anomalies',
    payload_storage=dict(
        compression='zstd',
        compression_level=3,
        format='jsonl',
        rows_per_shard=2000))
summarizer=dict(
    calculator=dict(
        stats_list=[
            'Average',
            'Min',
            'Max',
            'Median',
            'P75',
            'P90',
            'P99',
            ],
        type='ais_bench.benchmark.calculators.stable_perf_metric_calculator.StablePerfMetricCalculator'),
    type='ais_bench.benchmark.summarizers.default_perf.DefaultPerfSummarizer')
work_dir='/work/decode-dp4-tp4-ep16-20261026/runs/111_refine_d16k_cc91/aisbench/outputs/20261026_111453'