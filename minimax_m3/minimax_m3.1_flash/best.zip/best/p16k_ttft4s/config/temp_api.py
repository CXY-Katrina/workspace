from ais_bench.benchmark.models import VLLMCustomAPIChatStream

models = [
    dict(
        attr="service",
        type=VLLMCustomAPIChatStream,
        abbr='vllm-api-stream-chat',
        path="/work/pd-pure-perf-20261026-0022/tokenizer",
        model="minimax-m3.1-flash",
        api_key="",
        request_rate=3.101,
        retry=2,
        host_ip="197.13.50.1",
        host_port=31050,
        url="",
        max_out_len=1,
        batch_size=7,
        generation_kwargs=dict(
            temperature=0,
            ignore_eos=True,
        )
    )
]
